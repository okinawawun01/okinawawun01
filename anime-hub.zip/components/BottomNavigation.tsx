"use client"

import { usePathname } from "next/navigation"
import Link from "next/link"
import { Bell, Home, ShoppingCart, User, Menu } from "lucide-react"

export default function BottomNavigation() {
  const pathname = usePathname()

  const isActive = (path: string) => pathname === path

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-black/50 backdrop-blur-lg border-t border-white/10">
      <div className="max-w-screen-xl mx-auto flex justify-around items-center p-3">
        <Link
          href="/"
          className={`text-white ${isActive("/") ? "opacity-100" : "opacity-60"} hover:opacity-100 transition-opacity flex flex-col items-center`}
        >
          <Home className="w-6 h-6" />
          <span className="text-xs mt-1">Home</span>
        </Link>
        <Link
          href="/notifications"
          className={`text-white ${isActive("/notifications") ? "opacity-100" : "opacity-60"} hover:opacity-100 transition-opacity flex flex-col items-center relative`}
        >
          <Bell className="w-6 h-6" />
          <span className="text-xs mt-1">Notifications</span>
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
            1
          </span>
        </Link>
        <Link
          href="/subscribe"
          className={`text-white ${isActive("/subscribe") ? "opacity-100" : "opacity-60"} hover:opacity-100 transition-opacity flex flex-col items-center`}
        >
          <div className="relative">
            <ShoppingCart className="w-6 h-6" />
            <span className="absolute -top-1 -right-1 bg-cyan-400 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              3
            </span>
          </div>
          <span className="text-xs mt-1">Subscribe</span>
        </Link>
        <Link
          href="/profile"
          className={`text-white ${isActive("/profile") ? "opacity-100" : "opacity-60"} hover:opacity-100 transition-opacity flex flex-col items-center`}
        >
          <User className="w-6 h-6" />
          <span className="text-xs mt-1">Profile</span>
        </Link>
        <Link
          href="/menu"
          className={`text-white ${isActive("/menu") ? "opacity-100" : "opacity-60"} hover:opacity-100 transition-opacity flex flex-col items-center`}
        >
          <Menu className="w-6 h-6" />
          <span className="text-xs mt-1">Menu</span>
        </Link>
      </div>
    </nav>
  )
}

