"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { fetchPopularAnime } from "@/lib/tmdb"

export default function PopularAnime() {
  const [animes, setAnimes] = useState([])

  useEffect(() => {
    fetchPopularAnime().then(setAnimes)
  }, [])

  return (
    <section>
      <h2 className="text-white text-xl font-bold mb-4">Popular Anime</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        {animes.map((anime: any) => (
          <Link href={`/anime/${anime.id}`} key={anime.id} className="block">
            <div className="aspect-[3/4] bg-white/10 rounded-lg hover:ring-2 ring-white/20 transition-all overflow-hidden">
              <Image
                src={`https://image.tmdb.org/t/p/w500${anime.poster_path}`}
                alt={anime.title}
                width={500}
                height={750}
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <h3 className="mt-2 text-white text-sm font-medium truncate">{anime.title}</h3>
          </Link>
        ))}
      </div>
    </section>
  )
}

