"use client"

import { useState } from "react"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { useRouter } from "next/navigation"

export default function AnimeSearch() {
  const [query, setQuery] = useState("")
  const router = useRouter()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (query.trim()) {
      router.push(`/search?query=${encodeURIComponent(query)}`)
    }
  }

  return (
    <form onSubmit={handleSearch} className="flex-1 flex gap-2">
      <div className="flex-1 relative">
        <Input
          placeholder="Search anime..."
          className="pl-9 bg-white/10 border-white/20 text-white placeholder:text-white/50"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-white/50" />
      </div>
      <Button type="submit">Search</Button>
    </form>
  )
}

