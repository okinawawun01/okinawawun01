const API_KEY = process.env.NEXT_PUBLIC_TMDB_API_KEY
const BASE_URL = "https://api.themoviedb.org/3"

export async function fetchPopularAnime() {
  const res = await fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=16&sort_by=popularity.desc`)
  const data = await res.json()
  return data.results
}

export async function fetchTopRatedAnime() {
  const res = await fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=16&sort_by=vote_average.desc`)
  const data = await res.json()
  return data.results
}

export async function fetchRecentlyAddedAnime() {
  const res = await fetch(`${BASE_URL}/discover/tv?api_key=${API_KEY}&with_genres=16&sort_by=first_air_date.desc`)
  const data = await res.json()
  return data.results
}

export async function searchAnime(query: string) {
  const res = await fetch(`${BASE_URL}/search/tv?api_key=${API_KEY}&query=${encodeURIComponent(query)}&with_genres=16`)
  const data = await res.json()
  return data.results
}

export async function fetchAnimeDetails(id: string) {
  const res = await fetch(`${BASE_URL}/tv/${id}?api_key=${API_KEY}`)
  const data = await res.json()
  return data
}

