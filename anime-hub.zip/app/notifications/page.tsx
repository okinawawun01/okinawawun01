import AnimeSearch from "@/components/AnimeSearch"
import BottomNavigation from "@/components/BottomNavigation"

export default function NotificationsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      <header className="p-4 flex items-center gap-4">
        <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        <AnimeSearch />
      </header>

      <main className="p-4">
        <h1 className="text-3xl font-bold text-white mb-6">Notifications</h1>
        <p className="text-white">You have no new notifications.</p>
      </main>

      <BottomNavigation />
    </div>
  )
}

