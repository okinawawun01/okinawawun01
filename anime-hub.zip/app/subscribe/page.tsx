"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import AnimeSearch from "@/components/AnimeSearch"
import BottomNavigation from "@/components/BottomNavigation"

const plans = [
  { price: 49, name: "Basic" },
  { price: 99, name: "Standard" },
  { price: 199, name: "Premium" },
  { price: 299, name: "Ultra" },
  { price: 399, name: "Ultimate" },
  { price: 999, name: "VIP" },
]

const banks = ["BDO", "BPI", "Metrobank", "PNB", "Security Bank"]

export default function SubscribePage() {
  const [selectedPlan, setSelectedPlan] = useState<number | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<"gcash" | "bank" | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      <header className="p-4 flex items-center gap-4">
        <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        <AnimeSearch />
      </header>

      <main className="p-4">
        <h1 className="text-3xl font-bold text-white mb-6">Subscribe to AnimeHub</h1>

        <div className="bg-white/10 rounded-lg p-6 text-white mb-6">
          <h2 className="text-2xl font-bold mb-4">Choose your plan</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {plans.map((plan) => (
              <Button
                key={plan.price}
                onClick={() => setSelectedPlan(plan.price)}
                variant={selectedPlan === plan.price ? "default" : "outline"}
                className="h-auto py-4"
              >
                <div>
                  <div className="text-2xl font-bold">₱{plan.price}</div>
                  <div>{plan.name}</div>
                </div>
              </Button>
            ))}
          </div>
        </div>

        {selectedPlan && (
          <div className="bg-white/10 rounded-lg p-6 text-white mb-6">
            <h2 className="text-2xl font-bold mb-4">Choose payment method</h2>
            <RadioGroup onValueChange={(value) => setPaymentMethod(value as "gcash" | "bank")}>
              <div className="flex items-center space-x-2 mb-2">
                <RadioGroupItem value="gcash" id="gcash" />
                <Label htmlFor="gcash">GCash</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="bank" id="bank" />
                <Label htmlFor="bank">Bank Transfer</Label>
              </div>
            </RadioGroup>
          </div>
        )}

        {selectedPlan && paymentMethod === "gcash" && (
          <div className="bg-white/10 rounded-lg p-6 text-white mb-6">
            <h2 className="text-2xl font-bold mb-4">GCash Payment</h2>
            <form className="space-y-4">
              <div>
                <Label htmlFor="gcash-name">Name</Label>
                <Input id="gcash-name" placeholder="Enter your name" />
              </div>
              <div>
                <Label htmlFor="gcash-number">GCash Number</Label>
                <Input id="gcash-number" placeholder="Enter your GCash number" />
              </div>
              <div>
                <Label htmlFor="gcash-email">Email</Label>
                <Input id="gcash-email" type="email" placeholder="Enter your email" />
              </div>
              <div>
                <Label htmlFor="gcash-amount">Amount</Label>
                <Input id="gcash-amount" value={`₱${selectedPlan}`} disabled />
              </div>
              <Button type="submit" className="w-full">
                Pay with GCash
              </Button>
            </form>
          </div>
        )}

        {selectedPlan && paymentMethod === "bank" && (
          <div className="bg-white/10 rounded-lg p-6 text-white mb-6">
            <h2 className="text-2xl font-bold mb-4">Bank Transfer</h2>
            <form className="space-y-4">
              <div>
                <Label htmlFor="bank-name">Full Name</Label>
                <Input id="bank-name" placeholder="Enter your full name" />
              </div>
              <div>
                <Label htmlFor="bank-number">Account Number</Label>
                <Input id="bank-number" placeholder="Enter your account number" />
              </div>
              <div>
                <Label htmlFor="bank-email">Email</Label>
                <Input id="bank-email" type="email" placeholder="Enter your email" />
              </div>
              <div>
                <Label htmlFor="bank-select">Select Bank</Label>
                <Select>
                  <SelectTrigger id="bank-select">
                    <SelectValue placeholder="Select your bank" />
                  </SelectTrigger>
                  <SelectContent>
                    {banks.map((bank) => (
                      <SelectItem key={bank} value={bank}>
                        {bank}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="bank-amount">Amount</Label>
                <Input id="bank-amount" value={`₱${selectedPlan}`} disabled />
              </div>
              <Button type="submit" className="w-full">
                Pay with Bank Transfer
              </Button>
            </form>
          </div>
        )}
      </main>

      <BottomNavigation />
    </div>
  )
}

