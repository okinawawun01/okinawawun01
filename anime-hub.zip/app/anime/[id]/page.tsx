"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { fetchAnimeDetails } from "@/lib/tmdb"
import AnimeSearch from "@/components/AnimeSearch"
import BottomNavigation from "@/components/BottomNavigation"
import { Star, Play } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function AnimeDetails({ params }: { params: { id: string } }) {
  const [anime, setAnime] = useState<any>(null)

  useEffect(() => {
    fetchAnimeDetails(params.id).then(setAnime)
  }, [params.id])

  if (!anime) return <div>Loading...</div>

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      <header className="p-4 flex items-center gap-4">
        <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        <AnimeSearch />
      </header>

      <main className="p-4">
        <div className="bg-white/10 rounded-lg p-6 text-white">
          <div className="flex flex-col md:flex-row gap-6">
            <Image
              src={`https://image.tmdb.org/t/p/w500${anime.poster_path}`}
              alt={anime.title}
              width={300}
              height={450}
              className="rounded-lg"
            />
            <div>
              <h1 className="text-3xl font-bold mb-2">{anime.title}</h1>
              <p className="text-lg mb-4">{anime.overview}</p>
              <div className="flex items-center mb-2">
                <Star className="w-5 h-5 text-yellow-400 mr-1" />
                <span>
                  {anime.vote_average.toFixed(1)} ({anime.vote_count} votes)
                </span>
              </div>
              <p className="mb-2">Release Date: {anime.release_date}</p>
              <p className="mb-2">Genres: {anime.genres.map((g: any) => g.name).join(", ")}</p>
              <p className="mb-4">Runtime: {anime.runtime} minutes</p>
              <Button className="flex items-center gap-2">
                <Play className="w-4 h-4" />
                Watch Now
              </Button>
            </div>
          </div>
        </div>
      </main>

      <BottomNavigation />
    </div>
  )
}

