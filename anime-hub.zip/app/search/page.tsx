"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { searchAnime } from "@/lib/tmdb"
import AnimeSearch from "@/components/AnimeSearch"
import BottomNavigation from "@/components/BottomNavigation"

export default function SearchResults() {
  const searchParams = useSearchParams()
  const query = searchParams.get("query")
  const [results, setResults] = useState([])

  useEffect(() => {
    if (query) {
      searchAnime(query).then(setResults)
    }
  }, [query])

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      <header className="p-4 flex items-center gap-4">
        <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        <AnimeSearch />
      </header>

      <main className="p-4">
        <h1 className="text-2xl font-bold text-white mb-4">Search Results for "{query}"</h1>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {results.map((anime: any) => (
            <Link href={`/anime/${anime.id}`} key={anime.id} className="block">
              <div className="aspect-[3/4] bg-white/10 rounded-lg hover:ring-2 ring-white/20 transition-all overflow-hidden">
                <Image
                  src={`https://image.tmdb.org/t/p/w500${anime.poster_path}`}
                  alt={anime.title}
                  width={500}
                  height={750}
                  className="w-full h-full object-cover rounded-lg"
                />
              </div>
              <h3 className="mt-2 text-white text-sm font-medium truncate">{anime.title}</h3>
            </Link>
          ))}
        </div>
      </main>

      <BottomNavigation />
    </div>
  )
}

