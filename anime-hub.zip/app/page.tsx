import AnimeSearch from "@/components/AnimeSearch"
import PopularAnime from "@/components/PopularAnime"
import RecentlyAdded from "@/components/RecentlyAdded"
import TopRated from "@/components/TopRated"
import BottomNavigation from "@/components/BottomNavigation"

export default function AnimePlatform() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      {/* Header */}
      <header className="p-4 flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        </div>
        <AnimeSearch />
      </header>

      {/* Main Content */}
      <main className="p-4 space-y-8">
        <PopularAnime />
        <TopRated />
        <RecentlyAdded />
      </main>

      <BottomNavigation />
    </div>
  )
}

