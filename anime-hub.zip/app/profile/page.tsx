import AnimeSearch from "@/components/AnimeSearch"
import BottomNavigation from "@/components/BottomNavigation"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-400 to-blue-500">
      <header className="p-4 flex items-center gap-4">
        <div className="text-white font-bold text-2xl leading-none">アニメHUB</div>
        <AnimeSearch />
      </header>

      <main className="p-4">
        <h1 className="text-3xl font-bold text-white mb-6">Profile</h1>
        <p className="text-white">Your profile information will be displayed here.</p>
      </main>

      <BottomNavigation />
    </div>
  )
}

